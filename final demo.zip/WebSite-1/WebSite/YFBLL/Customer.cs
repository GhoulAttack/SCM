﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YFBLL
{
    public class Customer
    {
        public static bool amend(YF.Model.Customer customer, int id)
        {
            return YF.DAL.Customer.amend(customer, id);
        }
        public static YF.Model.Customer Getcustomer(int id)
        {
            return YF.DAL.Customer.Getcustomer(id);
        }
        public static bool del(int customer_id)
        {
            return YF.DAL.Customer.del(customer_id);
        }
        public static List<YF.Model.Customer> listforcustomer()
        {
            return YF.DAL.Customer.listforcustomer();
        }

        public static bool add(YF.Model.Customer customer)
        {
            return YF.DAL.Customer.add(customer);
        }
    }
}
