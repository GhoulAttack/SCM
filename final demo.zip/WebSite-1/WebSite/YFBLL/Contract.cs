﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YF.BLL
{
    public class Contract
    {
        public static bool amend(YF.Model.Contract contract, int id)
        {
            return YF.DAL.Contract.amend(contract, id);
        }
        public static YF.Model.Contract Getcontract(int id)
        {
            return YF.DAL.Contract.Getcontract(id);


        }
        public static bool del(int contract_id)
        {
            return YF.DAL.Contract.del(contract_id);
        }
        public static List<YF.Model.Contract> listforpayment()
        {
            return YF.DAL.Contract.listforpayment();
        }
        
        public static List<YF.Model.Contract> listforall()
            {
                return YF.DAL.Contract.listforall();
            }
        
        public static List<YF.Model.Contract> listforcollection()
        {
            return YF.DAL.Contract.listforcollection();

        }
        public static bool searchcontract(int contract_id)
        {
            return YF.DAL.Contract.searchcontract(contract_id);

        }
        public static List<YF.Model.Contract> listforcooperation()
        {
            return YF.DAL.Contract.listforcooperation();
        }
       
        public static bool add(YF.Model.Contract contract)
        {
            return YF.DAL.Contract.add(contract);
        }
        public static List<YF.Model.Contract> GetcontractbyID(int ID)
        {
            return YF.DAL.Contract.GetcontractbyID(ID);
        }
        public static DataTable GetcontractBYID(int id)
        {
            return YF.DAL.Contract.GetcontractBYID(id);
        }
    }
}

