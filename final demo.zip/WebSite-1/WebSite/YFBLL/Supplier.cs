﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YF.BLL
{
    public class Supplier
    {
        public static bool amend(YF.Model.Supplier supplier, int id)
        {
            return YF.DAL.Supplier.amend(supplier, id);
        }
        public static YF.Model.Supplier Getsupplier(int id)
        {
            return YF.DAL.Supplier.Getsupplier(id);
        }
        public static bool del(int supplier_id)
        {
            return YF.DAL.Supplier.del(supplier_id);
        }
        public static List<YF.Model.Supplier> listforsupplier()
        {
            return YF.DAL.Supplier.listforsupplier();
        }
       
        public static bool add(YF.Model.Supplier supplier)
        {
            return YF.DAL.Supplier.add(supplier);
        }
    }
}
