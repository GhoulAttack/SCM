﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YF.Model
{
    public class Customer
    {
        private int customer_id;
        private string customer_fullname;
        private string customer_name;
        private string address;
        private string area;
        private string type;

        public int Customer_id { get => customer_id; set => customer_id = value; }
        public string Customer_fullname { get => customer_fullname; set => customer_fullname = value; }
        public string Customer_name { get => customer_name; set => customer_name = value; }
        public string Address { get => address; set => address = value; }
        public string Area { get => area; set => area = value; }
        public string Type { get => type; set => type = value; }
    }
}
