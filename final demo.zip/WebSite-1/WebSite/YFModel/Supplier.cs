﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YF.Model
{
   public class Supplier
    {
        private int supplier_id;
        private string supplier_fullname;
        private string supplier_name;
        private string area;
        private string type;

        public int Supplier_id { get => supplier_id; set => supplier_id = value; }
        public string Supplier_fullname { get => supplier_fullname; set => supplier_fullname = value; }
        public string Supplier_name { get => supplier_name; set => supplier_name = value; }
        public string Area { get => area; set => area = value; }
        public string Type { get => type; set => type = value; }
    }
}
