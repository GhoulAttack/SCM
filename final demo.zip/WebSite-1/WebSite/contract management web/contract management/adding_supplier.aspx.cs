﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class adding_supplier : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

protected void Button1_Click(object sender, EventArgs e)
{
    YF.Model.Supplier supplier = new YF.Model.Supplier();
    supplier.Supplier_id = int.Parse(Request["contract_object"]);
    supplier.Supplier_fullname =Request["contract_fullname"];
    supplier.Supplier_name = Request["contract_name"];
    supplier.Area = Request["contract_object1"];
    supplier.Type = Request["contract_amount"];
    
    if (YF.BLL.Supplier.add(supplier) == true)
    {
        Response.Write("<script>alert('添加成功');</script>");
        Response.Redirect("begin_page.aspx");

    }
    else
    {
        Response.Write("<script>alert('添加失败');</script>");
    }
}
}