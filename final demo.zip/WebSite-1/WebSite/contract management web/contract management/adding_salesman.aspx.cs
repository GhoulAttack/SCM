﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class adding_salesman : System.Web.UI.Page
{
      protected void page_load(object sender, EventArgs e)
       {

      }

   
   }