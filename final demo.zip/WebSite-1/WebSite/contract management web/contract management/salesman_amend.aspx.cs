﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class salesman_amend : System.Web.UI.Page
{
    //protected void Page_Load(object sender, EventArgs e)
    //{
  
    //}

    //protected void Button1_Click(object sender, EventArgs e)
    //{
    //    YF.Model.Salesman salesman = new YF.Model.Salesman();
    //    int id = int.Parse(Request.QueryString["id"].ToString());
    //    salesman.Salesman_id = int.parse(request["salesman_object"]);
    //    salesman.Salesman_name = request["salesman_name"];
    //    salesman.Department = request["salesman_department"];
    //    salesman.Department_id = request["department_id"];

    //    if (YF.DAL.Salesman.amend(salesman, id) == true)
    //    {
    //        Response.Write("<script>alert('修改成功');</script>");
    //        Response.Redirect("collectioncontract_details.aspx");

    //    }
    //    else
    //    {
    //        Response.Write("<script>alert('修改失败');</script>");
    //    }
    //}
}

    
