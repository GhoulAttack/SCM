﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class collectioncontract_amend : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        YF.Model.Contract contract = new YF.Model.Contract();
        int id = int.Parse(Request.QueryString["id"].ToString());
        contract.Contract_type = Request["contract_type"];
        contract.Passworcontract_id = Convert.ToInt32(Request["contract_id"].Trim());
        contract.Contract_name = Request["contract_name"];
        contract.Contract_object = Request["contract_object"];
        contract.Contract_amount = int.Parse(Request["contract_amount"]);
        contract.Sign_date = Request["sign_date"];
        contract.Salesman = Request["salesman"];
        contract.First_invoice_date = Request.Params["first_invoice_date"];
        contract.First_invoice_amount = int.Parse(Request.Params["first_invoice_amount"]);
        contract.Second_invoice_date = Request.Params["second_invoice_date"];
        contract.Second_invoice_amount = int.Parse(Request.Params["second_invoice_amount"]);
        contract.Third_invoice_date = Request.Params["third_invoice_date"];
        contract.Third_invoice_amount = int.Parse(Request.Params["third_invoice_amount"]);
        contract.Note = Request.Params["note"];
        contract.Customer_name = Request.Params["customer_name"];
        contract.Version = Request.Params["version"];
        contract.Margin = Request.Params["margin"];
        contract.Payment_condition = Request.Params["payment_condition"];
        contract.Supplier_name = Request.Params["payment_condition"];
        contract.Cooperating_organization = Request.Params["payment_condition"];
        contract.Contract_content = Request.Params["contract_contetnt"];
        if (YF.BLL.Contract.amend(contract, id) == true)
        {
            Response.Write("<script>alert('修改成功');</script>");
            Response.Redirect("contract_page forcollection.aspx");

        }
        else
        {
            Response.Write("<script>alert('修改失败');</script>");
        }
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("contract_page forcollection.aspx");
    }


}