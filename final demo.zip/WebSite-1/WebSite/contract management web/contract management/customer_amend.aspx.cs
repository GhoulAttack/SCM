﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class customer_amend : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
  
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        YF.Model.Customer customer = new YF.Model.Customer();
        int id = int.Parse(Request.QueryString["id"].ToString());
        customer.Customer_id = int.Parse(Request["customer_id"]);
        customer.Customer_fullname = Request["customer_fullname"];
        customer.Customer_name = Request["customer_name"];
        customer.Address = Request["customer_add"];
        customer.Area = Request["customer_addtype"];
        customer.Type = Request["customer_type"];

        if (YF.DAL.Customer.amend(customer, id) == true)
        {
            Response.Write("<script>alert('修改成功');</script>");
            Response.Redirect("customer_records.aspx");

        }
        else
        {
            Response.Write("<script>alert('修改失败');</script>");
        }
    }
}

    
