﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
namespace YM.Utility
{
    /// <summary>
    /// 数据库操作类
    /// </summary>
    public class ClassDBOperator
    {
        private SqlConnection cn = new SqlConnection();//数据库连接对象
        public ClassDBOperator()
        {
            //cn = new SqlConnection(strConnection);
            // cn.ConnectionString = ConfigurationSettings.AppSettings["wzgl_DataConnectionString"].ToString();VS2005格式
            // cn.ConnectionString = ConfigurationManager.AppSettings["wzgl_DataConnectionString"].ToString();
            //从Web Config配置文件中获取数据库连接字符串，并赋值给数据库连接对象
            cn.ConnectionString = ConfigurationManager.ConnectionStrings["web"].ToString();
        }
        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="strConnection">连接字符串</param>
        public ClassDBOperator(string strConnection)
        {
            cn.ConnectionString = strConnection;
        }
        /// <summary>
        /// 通过SQL语句返回一个DataReader
        /// </summary>
        /// <param name="strSql">数据库SQL语句</param>
        /// <returns>SqlDataReader对象</returns>
        public SqlDataReader getReaderBySql(string strSql)
        {
            SqlDataReader MyReader;//= new SqlDataReader();
            SqlCommand cmd = new SqlCommand(strSql, cn);  //创建一个命令对象
            cmd.CommandType = CommandType.Text;
            try
            {
                if (cn.State != ConnectionState.Open)
                {
                    cn.Open();
                }
                MyReader = cmd.ExecuteReader();  //执行SQL命令获取数据
                cn.Close();
                return MyReader;
            }
            catch
            {
                cn.Close();
                return null;
            }

        }
        /// <summary>
        ///返回一个Table
        /// </summary>
        /// <param name="strSql">SQL语句</param>
        /// <param name="strErrorMessage">错误信息</param>
        /// <returns>DataTable</returns>
        public DataTable getDataTablebySql(string strSql, ref string strErrorMessage) //返回一个Table
        {
            DataTable myTable = new DataTable();
            SqlCommand cmd = new SqlCommand(strSql, cn);
            cmd.CommandType = CommandType.Text;
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            try
            {
                if (cn.State != ConnectionState.Open)
                {
                    cn.Open();
                }
                da.Fill(myTable);
                cn.Close();
                return myTable;
            }
            catch (Exception ex)
            {
                strErrorMessage = ex.Message;
                if (cn.State != ConnectionState.Closed)
                {
                    cn.Close();
                }
                return null;

            }
        }
        /// <summary>
        /// 返回一个值，一般用于COUNT(*),整数
        /// </summary>
        /// <param name="strSql"></param>
        /// <returns></returns>
        public int getaIntValueBySql(string strSql)  //返回一个值，一般用于COUNT(*),整数
        {
            int Count = 0;
            SqlCommand cmd = new SqlCommand(strSql, cn);
            cmd.CommandType = CommandType.Text;
            try
            {
                if (cn.State != ConnectionState.Open)
                {
                    cn.Open();
                }
                Count = (int)cmd.ExecuteScalar();
                cn.Close();
                return Count;
            }
            catch
            {
                cn.Close();
                return Count;
            }


        }
        /// <summary>
        /// 返回一个值，一般用sum等整数
        /// </summary>
        /// <param name="strSql"></param>
        /// <returns></returns>
        public float getaValueBySql(string strSql)  //返回一个值，一般用sum等整数
        {
            float fTotal = 0;
            SqlCommand cmd = new SqlCommand(strSql, cn);
            cmd.CommandType = CommandType.Text;
            try
            {
                if (cn.State != ConnectionState.Open)
                {
                    cn.Open();
                }
                fTotal = float.Parse(cmd.ExecuteScalar().ToString());
                cn.Close();
                return fTotal;
            }
            catch
            {
                cn.Close();
                return fTotal;
            }


        }
        /// <summary>
        /// 执行一个SQL语句
        /// </summary>
        /// <param name="strSql"></param>
        /// <returns></returns>
        public int ExcuteSql(string strSql)//执行一个SQL语句
        {
            int Count = 0;
            SqlCommand cmd = new SqlCommand(strSql, cn);
            cmd.CommandType = CommandType.Text;
            try
            {
                if (cn.State != ConnectionState.Open)
                {
                    cn.Open();
                }
                Count = cmd.ExecuteNonQuery();
                cn.Close();
                return Count;
            }
            catch
            {
                cn.Close();
                return Count;
            }
        }
        /// <summary>
        /// 根据参数执行
        /// </summary>
        /// <param name="strSql"></param>
        /// <param name="aPara"></param>
        /// <returns></returns>
        public int ExcuteSqlbyPara(string strSql, SqlParameter[] aPara)//根据参数执行
        {
            int Count = 0;
            SqlCommand cmd = new SqlCommand(strSql, cn);
            cmd.CommandType = CommandType.Text;
            foreach (SqlParameter aP in aPara)
            {
                cmd.Parameters.Add(aP);
            }
            try
            {
                if (cn.State != ConnectionState.Open)
                {
                    cn.Open();
                }
                Count = cmd.ExecuteNonQuery();
                cn.Close();
                return Count;
            }
            catch
            {
                cn.Close();
                return Count;
            }
        }
        /// <summary>
        /// 获得自动编号
        /// </summary>
        /// <param name="proName"></param>
        /// <param name="CodeName"></param>
        /// <returns></returns>
        public int getAutoCode(string procedueName, string CodeName)
        {
            //编写者:胡建华
            //编写时间:2014-3-14
            //'
            //'从数据库表TableName表中提取数据,并加1后回写到数据库中
            //'这些编号在生成时是自动增加的,原则上每提取一次,就加1,保证唯一
            //'fieldName为提取的字段
            SqlCommand comm = new SqlCommand();//数据库命令对象
            //打开数据库连接对象
            if (cn.State == ConnectionState.Closed)
            {
                cn.Open();
            }

            int CodeID = 0;
            //'命令对象属性设置
            comm.Connection = cn;
            comm.CommandType = CommandType.StoredProcedure;//  '表示存储过程
            comm.CommandText = procedueName;//   '保存在数据库中的存储过程名 

            comm.Parameters.Add(new SqlParameter("@RETURNVALUE", SqlDbType.Int, 4));//
            comm.Parameters["@RETURNVALUE"].Direction = ParameterDirection.ReturnValue;//  '表示由该参数返回一个值
            // '
            //'查询参数()
            //'
            comm.Parameters.Add(new SqlParameter("@CodeName", SqlDbType.VarChar, 30));//
            comm.Parameters["@CodeName"].Value = CodeName;//
            // '执行命令对象
            comm.ExecuteScalar();//
            //'
            //' 通过参数获取值
            // '
            CodeID = int.Parse(comm.Parameters["@RETURNVALUE"].Value.ToString());//
            cn.Close();//    '关闭连接
            return CodeID;//
        }
        /// <summary>
        /// http://www.cnblogs.com/gaojun/archive/2009/12/20/1628316.html
        /// </summary>
        public class StoreProcedure
        {
            // 连接字符串。
            private string connectionString;
            // 存储过程名称。
            private string storeProcedureName;

            //// <summary>
            /// 初始化 DataAccessHelper.StoreProceduer 对象。
            /// </summary>
            /// <param name="connectionString">数据库连接字符串。</param>

            public StoreProcedure(string connectionString)
            {
                this.connectionString = connectionString;
            }

            //// <summary>
            /// 初始化 DataAccessHelper.StoreProceduer 对象。
            /// </summary>
            /// <param name="connectionString">数据库连接字符串。</param>
            /// <param name="storeProcedureName">存储过程名称。</param>
            public StoreProcedure(string storeProcedureName, string connectionString)
            {
                this.connectionString = connectionString;
                this.storeProcedureName = storeProcedureName;
            }

            //// <summary>
            /// 获取或设置存储过程名称。
            /// </summary>
            public string StoreProcedureName
            {
                get { return this.storeProcedureName; }
                set { this.storeProcedureName = value; }
            }

            //// <summary>
            /// 执行操作类（Insert/Delete/Update）存储过程。
            /// </summary>
            /// <param name="paraValues">传递给存储过程的参数值列表。</param>
            /// <returns>受影响的行数。</returns>
            public int ExecuteNonQuery(params object[] paraValues)
            {

                using (SqlConnection connection = new SqlConnection(this.connectionString))
                {

                    SqlCommand command = this.CreateSqlCommand(connection);

                    try
                    {
                        this.DeriveParameters(command);
                        this.AssignParameterValues(command, paraValues);
                        connection.Open();
                        int affectedRowsCount = command.ExecuteNonQuery();
                        return affectedRowsCount;
                    }
                    catch
                    {
                        throw;
                    }
                }
            }

            //// <summary>
            /// 执行存储过程，返回 System.Data.DataTable。
            /// </summary>
            /// <param name="paraValues">传递给存储过程的参数值列表。</param>
            /// <returns>包含查询结果的 System.Data.DataTable。</returns>
            public DataTable ExecuteDataTable(params object[] paraValues)
            {

                using (SqlConnection connection = new SqlConnection(this.connectionString))
                {

                    SqlCommand command = this.CreateSqlCommand(connection);

                    try
                    {
                        this.DeriveParameters(command);
                        this.AssignParameterValues(command, paraValues);
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);
                        return dataTable;
                    }
                    catch
                    {
                        throw;
                    }
                }
            }

            //// <summary>
            /// 执行存储过程，填充指定的 System.Data.DataTable。
            /// </summary>
            /// <param name="dataTable">用于填充查询结果的 System.Data.DataTable。</param>
            /// <param name="paraValues">传递给存储过程的参数值列表。</param>
            public void ExecuteFillDataTable(DataTable dataTable, params object[] paraValues)
            {

                using (SqlConnection connection = new SqlConnection(this.connectionString))
                {

                    SqlCommand command = this.CreateSqlCommand(connection);

                    try
                    {
                        this.DeriveParameters(command);
                        this.AssignParameterValues(command, paraValues);
                        connection.Open();
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        adapter.Fill(dataTable);
                    }
                    catch
                    {
                        throw;
                    }
                }
            }

            //// <summary>
            /// 执行存储过程返回 System.Data.SqlClient.SqlDataReader，
            /// 在 System.Data.SqlClient.SqlDataReader 对象关闭时，数据库连接自动关闭。
            /// </summary>
            /// <param name="paraValues">传递给存储过程的参数值列表。</param>
            /// <returns>包含查询结果的 System.Data.SqlClient.SqlDataReader 对象。</returns>
            public SqlDataReader ExecuteDataReader(params object[] paraValues)
            {

                using (SqlConnection connection = new SqlConnection(this.connectionString))
                {

                    SqlCommand command = this.CreateSqlCommand(connection);

                    try
                    {
                        this.DeriveParameters(command);
                        this.AssignParameterValues(command, paraValues);
                        connection.Open();
                        return command.ExecuteReader(CommandBehavior.CloseConnection);
                    }
                    catch
                    {
                        throw;
                    }
                }
            }

            //// <summary>
            /// 执行查询，并返回查询所返回的结果集中第一行的第一列。忽略其他列或行。
            /// </summary>
            /// <param name="paraValues">传递给存储过程的参数值列表。</param>
            /// <returns>结果集中第一行的第一列或空引用（如果结果集为空）。</returns>
            public object ExecuteScalar(params object[] paraValues)
            {

                using (SqlConnection connection = new SqlConnection(this.connectionString))
                {

                    SqlCommand command = this.CreateSqlCommand(connection);

                    try
                    {
                        this.DeriveParameters(command);
                        this.AssignParameterValues(command, paraValues);
                        connection.Open();
                        object result = command.ExecuteScalar();
                        //string r = command.Parameters[1].Value.ToString();
                        return result;
                    }
                    catch
                    {
                        throw;
                    }
                }
            }

            //// <summary>
            /// 从在 System.Data.SqlClient.SqlCommand 中指定的存储过程中检索参数信息并填充指定的 
            /// System.Data.SqlClient.SqlCommand 对象的 System.Data.SqlClient.SqlCommand.Parameters 集  合。
            /// </summary>
            /// <param name="sqlCommand">将从其中导出参数信息的存储过程的 System.Data.SqlClient.SqlCommand 对象。</param>
            internal void DeriveParameters(SqlCommand sqlCommand)
            {
                try
                {
                    sqlCommand.Connection.Open();
                    SqlCommandBuilder.DeriveParameters(sqlCommand);
                    sqlCommand.Connection.Close();
                }
                catch
                {
                    if (sqlCommand.Connection != null)
                    {
                        sqlCommand.Connection.Close();
                    }
                    throw;
                }
            }

            // 用指定的参数值列表为存储过程参数赋值。
            private void AssignParameterValues(SqlCommand sqlCommand, params object[] paraValues)
            {
                if (paraValues != null)
                {
                    if ((sqlCommand.Parameters.Count - 1) != paraValues.Length)
                    {
                        throw new ArgumentNullException("The number of parameters does not match number of values for stored procedure.");
                    }
                    for (int i = 0; i < paraValues.Length; i++)
                    {
                        sqlCommand.Parameters[i + 1].Value = (paraValues[i] == null) ? DBNull.Value : paraValues[i];
                    }
                }
            }

            // 创建用于执行存储过程的 SqlCommand。
            private SqlCommand CreateSqlCommand(SqlConnection connection)
            {

                SqlCommand command = new SqlCommand(this.storeProcedureName, connection);
                command.CommandType = CommandType.StoredProcedure;

                return command;
            }

            //-------------------------------------这一部分是我完善的,因为没有执行后返回存储过程中的返回值的函数-----------------------

            /// <summary>
            /// 执行存储过程,返回存储过程定义的返回值,注意存储过程中参数(paraValues)如果为返回值赋为空,其它值位置对应好
            /// </summary>
            /// <param name="output">返回存储过程中定义的返回值数组</param>
            /// <param name="outParaNum">存储过程中返回值的个数</param>
            /// <param name="paraValues">存储过程全部参数值</param>

            public void ExecProcOutput(out object[] output, int outParaNum, params object[] paraValues)
            {
                using (SqlConnection connection = new SqlConnection(this.connectionString))
                {

                    SqlCommand command = this.CreateSqlCommand(connection);
                    output = new object[outParaNum];//存储过程中返回值的个数
                    try
                    {
                        this.DeriveParameters(command);
                        this.AssignParameterValues(command, paraValues);
                        connection.Open();
                        command.ExecuteNonQuery();
                        for (int i = 0; i < outParaNum; i++)//将存储过程返回的参数值返回到程序中
                        {
                            output[i] = command.Parameters[1].Value;
                        }
                    }
                    catch
                    {
                        throw;
                    }
                }
            }
        }
    }
}

