﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YF.DAL
{
    public class Customer
    {
        public static bool amend(YF.Model.Customer customer, int id)
        {
            string sql = "UPDATE customer SET Customer_id= " + customer.Customer_id + ",Customer_fullname= '" + customer.Customer_fullname + "',Customer_name='" + customer.Customer_name + "',Address='" + customer.Address + "',Area='" + customer.Area + "',Type='" + customer.Type + "'where Customer_id=" + id + "";
            int i = YF.SqlHelper.SqlHelper.ExecuteSql(sql);
            bool result = false;
            if (i > 0)
            {
                result = true;
            }
            return result;

        }
        public static YF.Model.Customer Getcustomer(int id)
        {
            string sql = "select *from customer where Customer_id=" + id + "";
            DataTable dataTable = YF.SqlHelper.SqlHelper.Query(sql).Tables[0];
            return Dttolist1(dataTable)[0];
        }

        public static bool del(int Customer_id)
        {
            string strsql = "delete from customer where Customer_id =" + Customer_id + "";
            bool result = false;
            int i = YF.SqlHelper.SqlHelper.ExecuteSql(strsql);
            if (i > 0)
            {
                result = true;
            }
            return result;
        }
        public static bool add(YF.Model.Customer customer)
        {
            bool result = false;
            string strsql1 = "insert into customer(Customer_id, Customer_fullname,Customer_name,Address,Area,Type) values (" + customer.Customer_id + ",'" + customer.Customer_fullname + "','" + customer.Customer_name + "','" + customer.Address + "','" + customer.Area + "','" + customer.Type + "')";

            int i = YF.SqlHelper.SqlHelper.ExecuteSql(strsql1);
            if (i > 0)
            {
                result = true;
            }
            return result;
        }
        public static List<YF.Model.Customer> listforcustomer()
        {
            string strsql = "select Customer_id, Customer_fullname,Customer_name,Address,Area,Type from customer";

            DataTable dataTable = YF.SqlHelper.SqlHelper.Query(strsql).Tables[0];
            return Dttolist(dataTable);

        }


        public static List<YF.Model.Customer> Dttolist(DataTable dt)
        {
            List<YF.Model.Customer> list = new List<YF.Model.Customer>();


            for (int i = 0; i < dt.Rows.Count; i++)
            {
                YF.Model.Customer customer = new Model.Customer();
                customer.Customer_id = int.Parse(dt.Rows[i]["Customer_id"].ToString());
                customer.Customer_fullname = dt.Rows[i]["Customer_fullname"].ToString();
                customer.Customer_name = dt.Rows[i]["Customer_name"].ToString();
                customer.Address = dt.Rows[i]["Address"].ToString();
                customer.Area = dt.Rows[i]["Area"].ToString();
                customer.Type = dt.Rows[i]["Type"].ToString();




                list.Add(customer);
            }
            return list;

        }
        public static List<YF.Model.Customer> Dttolist1(DataTable dt)
        {
            List<YF.Model.Customer> list = new List<YF.Model.Customer>();


            for (int i = 0; i < dt.Rows.Count; i++)
            {
                YF.Model.Customer customer = new Model.Customer();
                customer.Customer_id = int.Parse(dt.Rows[i]["Customer_id"].ToString());
                customer.Customer_fullname = dt.Rows[i]["Customer_fullname"].ToString();
                customer.Customer_name = dt.Rows[i]["Customer_name"].ToString();
                customer.Address = dt.Rows[i]["Address"].ToString();
                customer.Area = dt.Rows[i]["Area"].ToString();
                customer.Type = dt.Rows[i]["Type"].ToString();



                list.Add(customer);
            }
            return list;

        }
    }
}
