﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace YF.DAL
{/// <summary>
/// 用户数据访问类
/// </summary>
    public class User
    {
        /// <summary>
        ///add users
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        public static bool add(YF.Model.User user)
        {
            bool result = false;
            string strsql = "insert into t_user(username,password,state) values('" + user.Username + "','" + user.Password + "'," + user.State + ")";
            int i = YF.SqlHelper.SqlHelper.ExecuteSql(strsql);
            if (i > 0)
            {
                result = true;
            }
            return result;

        }
        public static bool Search(string username)
        {
            bool result = false;
            string strsql = "select * from t_user where username='" + username + "'";
            DataTable dataTable = YF.SqlHelper.SqlHelper.Query(strsql).Tables[0];
            if (dataTable.Rows.Count == 0)
            {
                result = true;
            }
            else
            {
                result = false;
            }
            return result;
        }
        public static bool login(string username,string password)
        {
            bool result = false;
            string strsql = "select * from t_user where username='" + username + "'and password='"+password+"'";
            DataTable dataTable = YF.SqlHelper.SqlHelper.Query(strsql).Tables[0];
            if (dataTable.Rows.Count != 0)
            {
                result = true;
            }
            else
            {
                result = false;
            }
            return result;
        }

    }
}
