﻿using System;
using System.Web.UI.WebControls;
using YF;
public partial class reg : System.Web.UI.Page
{
    protected void Page_Load(object sender,EventArgs e)
    {

    }
  



    protected void Button1_Click(object sender, EventArgs e)
    {
        YF.Model.User user = new YF.Model.User();
        user.Username = this.username.Text;
        user.Password = this.password.Text;

        user.State = 1;
        if (YF.BLL.User.Search(this.username.Text) == false)
        {
            ///System.Web.HttpContext.Current.Response.Write("用户名已存在");
            Response.Write("<script>alert('用户名已存在');</script>");
           /// Response.Redirect("reg.aspx");

        }
        else if (this.username.Text == "" || this.password.Text == "")
            {
                Response.Write("<script>alert('注册信息不能为空');</script>");
            }
        

        
        else
        {
            if (YF.BLL.User.add(user) == true)
            {
               
                    System.Web.HttpContext.Current.Response.Write("注册成功");
                    Response.Write("<script>alert('注册成功');</script>");


                    Response.Redirect("login.aspx");
             }
            
            else
            {
                ///System.Web.HttpContext.Current.Response.Write("注册失败");
                Response.Write("<script>alert('注册失败');</script>");
            }
        }
    }
}