﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class supplier_amend : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
  
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        YF.Model.Supplier supplier = new YF.Model.Supplier();
        int id = int.Parse(Request.QueryString["id"].ToString());
        supplier.Supplier_id = int.Parse(Request["contract_object"]);
        supplier.Supplier_fullname = Request["contract_fullname"];
        supplier.Supplier_name = Request["contract_name"];
        supplier.Area = Request["contract_object1"];
        supplier.Type = Request["contract_amount"];

        if (YF.BLL.Supplier.amend(supplier, id) == true)
        {
            Response.Write("<script>alert('修改成功');</script>");
            Response.Redirect("collectioncontract_details.aspx");

        }
        else
        {
            Response.Write("<script>alert('修改失败');</script>");
        }
    }
}

    
