﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class SEARCH : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
      
    }
    public override void VerifyRenderingInServerForm(Control control)
    {
        return;
    }
    protected void btnQuery_Click(object sender, EventArgs e)
    {
        if (this.contract_id.Text.Trim() != null && this.contract_id.Text.Trim() != "")
        {
            DataTable stockTable = new DataTable();
            stockTable = YF.BLL.Contract.GetcontractBYID(int.Parse(this.contract_id.Text.Trim()));
            this.gridStock.DataSource = stockTable;
            // this.gridStock.DataKeyNames = new string[] { "Passworcontract_id" };  //加上关键字
            this.gridStock.DataBind();
        }
       // Response.Redirect("begin_page.aspx");
    }

    protected void gridStock_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        DataTable stockTable = new DataTable();
       // stockTable = YF.BLL.Contract.GetcontractBYID();
        this.gridStock.DataSource = stockTable;
        // this.gridStock.DataKeyNames = new string[] { "Passworcontract_id" };  //加上关键字
        this.gridStock.DataBind();
       // Response.Redirect("begin_page.aspx");
    }
}