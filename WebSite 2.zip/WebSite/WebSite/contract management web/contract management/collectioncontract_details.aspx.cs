﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using YF.Model;

public partial class cooperationcontract_details : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        int id = int.Parse(Request.QueryString["id"].ToString());
        YF.Model.Contract contract = YF.BLL.Contract.Getcontract(id);
        this.contract_type.Text = contract.Contract_type;
        this.Passworcontract_id.Text = contract.Passworcontract_id.ToString();
        this.contract_name.Text = contract.Contract_name.ToString();
        this.contract_object.Text = contract.Contract_object.ToString();
        this.contract_amount.Text = contract.Contract_amount.ToString();

        this.sign_date.Text = contract.Sign_date.ToString();
        this.salesman.Text = contract.Salesman.ToString();

        this.first_invoice_date.Text = contract.First_invoice_date.ToString();
        this.first_invoice_amount.Text = contract.First_invoice_amount.ToString();
        this.second_invoice_date.Text = contract.Second_invoice_date.ToString();
        this.second_invoice_amount.Text = contract.Second_invoice_date.ToString();
        this.third_invoice_date.Text = contract.Third_invoice_date.ToString();
        this.third_invoice_amount.Text = contract.Third_invoice_amount.ToString();
        this.note.Text = contract.Note.ToString();
        this.contract_content.Text = contract.Contract_content.ToString();
        this.customer_name.Text = contract.Contract_content.ToString();
        this.version.Text = contract.Version.ToString();
        this.margin.Text = contract.Margin.ToString();
        this.payment_condition.Text = contract.Payment_condition.ToString();

   
    }

    protected void cooperating_organization_TextChanged(object sender, EventArgs e)
    {

    }
}