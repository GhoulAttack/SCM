﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("reg.aspx");
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        string username = this.username.Text;
        string password = this.password.Text;
        if (YF.BLL.User.login(username, password) == true)
        {
            Response.Write("< script language = 'javascript' > alert('登陆成功') </ script > ");

            Response.Redirect("begin_page.aspx");

        }
        else
        {
            ///System.Web.HttpContext.Current.Response.Write("登陆失败");
            Response.Write("<script>alert('登录失败');</script>");

           Response.Redirect("login.aspx");
        }

    }
}