﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YF.DAL
{
    public class Contract
    {
        public static bool amend(YF.Model.Contract contract,int id)
        {
            string sql = "UPDATE contract_table SET Contract_type= '"+contract.Contract_type +"',Passworcontract_id= " +contract.Passworcontract_id+ ",Contract_name='"+ contract.Contract_name + "',Contract_object='"+contract.Contract_object+"',Contract_amount="+contract.Contract_amount+",Sign_date='"+contract.Sign_date+"',Salesman='"+contract.Salesman+"',First_invoice_date='"+contract.First_invoice_date+"' ,First_invoice_amount="+contract.First_invoice_amount+",Second_invoice_date='"+contract.Second_invoice_date+"',Second_invoice_amount="+contract.Second_invoice_amount+",Third_invoice_date='"+contract.Third_invoice_date+"',Third_invoice_amount="+contract.Third_invoice_amount+",Note='"+contract.Note+"',Customer_name='"+contract.Customer_name+"',Version='"+contract.Version+"',Margin="+contract.Margin+",Payment_condition='"+contract.Payment_condition+"',Supplier_name='"+contract.Supplier_name+"', Cooperating_organization='"+contract.Cooperating_organization+"',Contract_content='"+contract.Contract_content+"'where Passworcontract_id="+id+"";
            int i = YF.SqlHelper.SqlHelper.ExecuteSql(sql);
            bool result = false;
            if (i > 0)
            {
                result = true;
            }
            return result;
        
    }
        public static YF.Model.Contract Getcontract(int id)
        {
            string sql = "select *from contract_table where Passworcontract_id="+id+"" ; 
            DataTable dataTable = YF.SqlHelper.SqlHelper.Query(sql).Tables[0];
            return Dttolist1(dataTable)[0];
        }

        public static bool del(int contract_id)
        {
            string strsql = "delete from contract_table where Passworcontract_id =" + contract_id + "";
            bool result = false;
            int i = YF.SqlHelper.SqlHelper.ExecuteSql(strsql);
            if (i > 0)
            {
                result = true;
            }
            return result;
        }
        public static bool add(YF.Model.Contract contract)
        {
            bool result = false;
            string strsql1 = "insert into contract_table(Contract_type, Passworcontract_id,Contract_name,Contract_object,Contract_amount,Sign_date,Salesman,First_invoice_date,First_invoice_amount,Second_invoice_date,Second_invoice_amount,Third_invoice_date,Third_invoice_amount,Note,Customer_name,Version,Margin,Payment_condition,Supplier_name, Cooperating_organization,Contract_content) values ('" + contract.Contract_type + "'," + contract.Passworcontract_id + ",'" + contract.Contract_name + "','" + contract.Contract_object + "'," + contract.Contract_amount + ",'" + contract.Sign_date + "','" + contract.Salesman + "','" + contract.First_invoice_date + "','" + contract.First_invoice_amount + "','" + contract.Second_invoice_date + "'," + contract.Second_invoice_amount + ",'" + contract.Third_invoice_date + "'," + contract.Third_invoice_amount + ",'" + contract.Note + "','" + contract.Customer_name + "','" + contract.Version + "'," + contract.Margin + ",'" + contract.Payment_condition + "','" + contract.Supplier_name + "','" + contract.Cooperating_organization + "','" + contract.Contract_content + "')";

            int i = YF.SqlHelper.SqlHelper.ExecuteSql(strsql1);
            if (i > 0)
            {
                result = true;
            }
            return result;
        }
        public static List<YF.Model.Contract> listforpayment()
        {
            string strsql = "select Contract_type, Passworcontract_id,Contract_name,Contract_object,Contract_amount,Salesman,Sign_date from contract_table where Contract_type='"+"付款合同"+"'";

            DataTable dataTable = YF.SqlHelper.SqlHelper.Query(strsql).Tables[0];
            return Dttolist(dataTable);

        }
        public static List<YF.Model.Contract> GetcontractbyID(int ID)
        {
            string strsql = "select Contract_type, Passworcontract_id,Contract_name,Contract_object,Contract_amount,Salesman,Sign_date from contract_table where Passworcontract_id" + ID + "";
            DataTable dataTable = YF.SqlHelper.SqlHelper.Query(strsql).Tables[0];
            return Dttolist(dataTable);

        }
        public static List<YF.Model.Contract> listforall()
        {
            string strsql = "select Contract_type, Passworcontract_id,Contract_name,Contract_object,Contract_amount,Salesman,Sign_date from contract_table ";

            DataTable dataTable = YF.SqlHelper.SqlHelper.Query(strsql).Tables[0];
            return Dttolist(dataTable);

        }
        

        public static List<YF.Model.Contract> listforcollection()
        {
            string strsql = "select Contract_type, Passworcontract_id,Contract_name,Contract_object,Contract_amount,Salesman,Sign_date from contract_table where Contract_type='" + "收款合同" + "'";

            DataTable dataTable = YF.SqlHelper.SqlHelper.Query(strsql).Tables[0];
            return Dttolist(dataTable);

        }
        public static List<YF.Model.Contract> listforcooperation()
        {
            string strsql = "select Contract_type, Passworcontract_id,Contract_name,Contract_object,Contract_amount,Salesman,Sign_date from contract_table where Contract_type='" + "合作合同" + "'";

            DataTable dataTable = YF.SqlHelper.SqlHelper.Query(strsql).Tables[0];
            return Dttolist(dataTable);

        }
       
        public static bool searchcontract(int passworcontract_id)
        {
            bool result = false;
            string strsql = "select * from contract_table where Passworcontract_id=" + passworcontract_id + "";
            DataTable dataTable = YF.SqlHelper.SqlHelper.Query(strsql).Tables[0];
            if (dataTable.Rows.Count != 0)
            {
                result = true;
            }
            else
            {
                result = false;
            }
            return result;
        }
        public static List<YF.Model.Contract> Dttolist(DataTable dt)
        {
            List<YF.Model.Contract> list = new List<YF.Model.Contract>();


            for (int i = 0; i < dt.Rows.Count; i++)
            {
                YF.Model.Contract contract = new Model.Contract();
                contract.Contract_type = dt.Rows[i]["Contract_type"].ToString();
                contract.Passworcontract_id =int.Parse(dt.Rows[i]["Passworcontract_id"].ToString());
                contract.Contract_name = dt.Rows[i]["Contract_name"].ToString();
                contract.Contract_object = dt.Rows[i]["Contract_object"].ToString();
                contract.Contract_amount = int.Parse(dt.Rows[i]["Contract_amount"].ToString());   
                contract.Salesman = dt.Rows[i]["Salesman"].ToString();
                contract.Sign_date = dt.Rows[i]["Sign_date"].ToString();
                


                list.Add(contract);
            }
            return list;

        }
        public static List<YF.Model.Contract> Dttolist1(DataTable dt)
        {
            List<YF.Model.Contract> list = new List<YF.Model.Contract>();


            for (int i = 0; i < dt.Rows.Count; i++)
            {
                YF.Model.Contract contract = new Model.Contract();
                contract.Contract_type = dt.Rows[i]["Contract_type"].ToString();
                contract.Passworcontract_id = int.Parse(dt.Rows[i]["Passworcontract_id"].ToString());
                contract.Contract_name = dt.Rows[i]["Contract_name"].ToString();
                contract.Contract_object = dt.Rows[i]["Contract_object"].ToString();
                contract.Contract_amount = int.Parse(dt.Rows[i]["Contract_amount"].ToString());
                contract.Salesman = dt.Rows[i]["Salesman"].ToString();
                contract.Sign_date = dt.Rows[i]["Sign_date"].ToString();
                contract.First_invoice_date = dt.Rows[i]["First_invoice_date"].ToString();
                contract.First_invoice_amount = int.Parse(dt.Rows[i]["First_invoice_amount"].ToString());
                contract.Second_invoice_date = dt.Rows[i]["Second_invoice_date"].ToString();
                contract.Second_invoice_amount = int.Parse(dt.Rows[i]["Second_invoice_amount"].ToString());
                contract.Third_invoice_date = dt.Rows[i]["Third_invoice_date"].ToString();
                contract.Third_invoice_amount = int.Parse(dt.Rows[i]["Third_invoice_amount"].ToString());
                contract.Note = dt.Rows[i]["Note"].ToString();
                contract.Customer_name = dt.Rows[i]["Customer_name"].ToString();
                contract.Cooperating_organization = dt.Rows[i]["Cooperating_organization"].ToString();
                contract.Version = dt.Rows[i]["Version"].ToString();
                contract.Margin = dt.Rows[i]["Margin"].ToString();
                contract.Payment_condition = dt.Rows[i]["Payment_condition"].ToString();
                contract.Contract_content = dt.Rows[i]["Contract_content"].ToString();




                list.Add(contract);
            }
            return list;

        }
        public static DataTable GetcontractBYID(int id)
        {
            YM.Utility.ClassDBOperator dac = new YM.Utility.ClassDBOperator();
            string strSql = "select Contract_type, Passworcontract_id,Contract_name,Contract_object,Contract_amount,Salesman,Sign_date from contract_table where Passworcontract_id=" + id + ""; ;
            // strSql = strSql + " FROM [库存详细记录] ";
            // strSql = strSql + strCondition;
            //   strSql = strSql + " ORDER BY 品名";
            //  string strSql = "select Contract_type, Passworcontract_id,Contract_name,Contract_object,Contract_amount,Salesman,Sign_date from contract_table where Contract_type='" + "收款合同" + "'";
            string strError = "";

            DataTable myTable = dac.getDataTablebySql(strSql, ref strError);
            return myTable;
        }
    }
}
