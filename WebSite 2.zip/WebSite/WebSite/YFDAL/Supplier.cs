﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YF.DAL
{
    public class Supplier
    {
        public static bool amend(YF.Model.Supplier supplier, int id)
        {
            string sql = "UPDATE supplier SET Supplier_id= " + supplier.Supplier_id + ",Supplier_fullname= '" + supplier.Supplier_fullname + "',Supplier_name='" + supplier.Supplier_name + "',Area='" + supplier.Area + "',Type='" + supplier.Type + "'where Supplier_id=" + id + "";
            int i = YF.SqlHelper.SqlHelper.ExecuteSql(sql);
            bool result = false;
            if (i > 0)
            {
                result = true;
            }
            return result;

        }
        public static YF.Model.Supplier Getsupplier(int id)
        {
            string sql = "select *from supplier where Supplier_id=" + id + "";
            DataTable dataTable = YF.SqlHelper.SqlHelper.Query(sql).Tables[0];
            return Dttolist1(dataTable)[0];
        }

        public static bool del(int Supplier_id)
        {
            string strsql = "delete from supplier where Supplier_id =" + Supplier_id + "";
            bool result = false;
            int i = YF.SqlHelper.SqlHelper.ExecuteSql(strsql);
            if (i > 0)
            {
                result = true;
            }
            return result;
        }
        public static bool add(YF.Model.Supplier supplier)
        {
            bool result = false;
            string strsql1 = "insert into supplier(Supplier_id, Supplier_fullname,Supplier_name,Area,Type) values (" + supplier.Supplier_id + ",'" + supplier.Supplier_fullname + "','" + supplier.Supplier_name + "','" + supplier.Area + "','" + supplier.Type + "')";

            int i = YF.SqlHelper.SqlHelper.ExecuteSql(strsql1);
            if (i > 0)
            {
                result = true;
            }
            return result;
        }
        public static List<YF.Model.Supplier> listforsupplier()
        {
            string strsql = "select Supplier_id, Supplier_fullname,Supplier_name,Area,Type from supplier";

            DataTable dataTable = YF.SqlHelper.SqlHelper.Query(strsql).Tables[0];
            return Dttolist(dataTable);

        }
        
        
        public static List<YF.Model.Supplier> Dttolist(DataTable dt)
        {
            List<YF.Model.Supplier> list = new List<YF.Model.Supplier>();


            for (int i = 0; i < dt.Rows.Count; i++)
            {
                YF.Model.Supplier supplier = new Model.Supplier();
                supplier.Supplier_id = int.Parse(dt.Rows[i]["Supplier_id"].ToString());
                supplier.Supplier_fullname = dt.Rows[i]["Supplier_fullname"].ToString();
                supplier.Supplier_name = dt.Rows[i]["Supplier_name"].ToString();
                supplier.Area = dt.Rows[i]["Area"].ToString();
                supplier.Type = dt.Rows[i]["Type"].ToString();
              



                list.Add(supplier);
            }
            return list;

        }
        public static List<YF.Model.Supplier> Dttolist1(DataTable dt)
        {
            List<YF.Model.Supplier> list = new List<YF.Model.Supplier>();


            for (int i = 0; i < dt.Rows.Count; i++)
            {
                YF.Model.Supplier supplier = new Model.Supplier();
                supplier.Supplier_id = int.Parse(dt.Rows[i]["Supplier_id"].ToString());
                supplier.Supplier_fullname = dt.Rows[i]["Supplier_fullname"].ToString();
                supplier.Supplier_name = dt.Rows[i]["Supplier_name"].ToString();
                supplier.Area = dt.Rows[i]["Area"].ToString();
                supplier.Type = dt.Rows[i]["Type"].ToString();



                list.Add(supplier);
            }
            return list;

        }
    }
}
