﻿using System;
using System.Collections.Generic;
using System.Text;

namespace YF.Model
{
    public class User
    {
        private int id;

        public int Id
        {
            get => id;
            set => id = value;
        }

        private string username;
        public string Username { get => username; set => username = value; }


        private string password;
        public string Password { get => password; set => password = value; }



        private int state;
        public int State { get => state; set => state = value; }
      
       



    }
}
