﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YF.Model
{
    public  class Contract

    {
        private string contract_type;
       private int passworcontract_id ;
        private string contract_name ;
        private string contract_object ;
        private int contract_amount ;
        private string sign_date ;
        private string salesman ;
        private string first_invoice_date ;
        private int first_invoice_amount ;
        private string second_invoice_date ;
        private int second_invoice_amount ;
        private string third_invoice_date ;
        private int third_invoice_amount  ;
        private string note;
        private string customer_name ;
        private string version ;
        private string margin ;
        private string payment_condition ;
        private string supplier_name ;
        private string cooperating_organization ;
        private string contract_content ;

        public string Contract_type { get => contract_type; set => contract_type = value; }
        public int Passworcontract_id { get => passworcontract_id; set => passworcontract_id = value; }
        public string Contract_name { get => contract_name; set => contract_name = value; }
        public string Contract_object { get => contract_object; set => contract_object = value; }
        public int Contract_amount { get => contract_amount; set => contract_amount = value; }
        public string Sign_date { get => sign_date; set => sign_date = value; }
        public string Salesman { get => salesman; set => salesman = value; }
        public string First_invoice_date { get => first_invoice_date; set => first_invoice_date = value; }
        public int First_invoice_amount { get => first_invoice_amount; set => first_invoice_amount = value; }
        public string Second_invoice_date { get => second_invoice_date; set => second_invoice_date = value; }
        public int Second_invoice_amount { get => second_invoice_amount; set => second_invoice_amount = value; }
        public string Third_invoice_date { get => third_invoice_date; set => third_invoice_date = value; }
        public int Third_invoice_amount { get => third_invoice_amount; set => third_invoice_amount = value; }
        public string Customer_name { get => customer_name; set => customer_name = value; }
        public string Version { get => version; set => version = value; }
        public string Margin { get => margin; set => margin = value; }
        public string Payment_condition { get => payment_condition; set => payment_condition = value; }
        public string Supplier_name { get => supplier_name; set => supplier_name = value; }
        public string Cooperating_organization { get => cooperating_organization; set => cooperating_organization = value; }
        public string Contract_content { get => contract_content; set => contract_content = value; }
        public string Note { get => note; set => note = value; }
    }
}
